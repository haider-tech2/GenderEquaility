export default function News() {
  return (
    <div className="container">
      <h1>News</h1>
      <ul>
        <li>Campaign A: Workplace equality awareness</li>
        <li>Campaign B: Fighting gender stereotypes in schools</li>
        <li>Campaign C: Support networks for minorities</li>
      </ul>
    </div>
  )
}
